//#pragma once

class Percepcao {
    public:
    int posx;
    int posy;
    bool sucesso;
    int objeto;
};